Better View Pro — Desktop App
==============================


FIRST TIME SETUP
-----------------
1. Install Node.js from https://nodejs.org (LTS version)
2. Open Command Prompt (no admin needed for normal builds)
3. Navigate to this folder:
   cd C:\Users\blake\OneDrive\Desktop\betterview-desktop
4. Run:
   npm install
5. Run:
   npm run build:win
6. Find installer in the dist\ folder and run it

NOTE: If step 5 gives a "Cannot create symbolic link" error, see TROUBLESHOOTING below.


UPDATING THE APP (every time you get new changes)
--------------------------------------------------
Option A - Double-click update.bat  <-- RECOMMENDED (handles cache cleanup automatically)
Option B - Open Command Prompt, go to this folder, run: npm run build:win

Then run the new installer from the dist\ folder.


SETTING UP AUTO-UPDATES (one time, so all computers update automatically)
--------------------------------------------------------------------------

Step 1 - Create a GitHub repository:
  1. Go to https://github.com and sign in as blakebvhi-op
  2. Click the + button (top right) > New repository
  3. Name it exactly: betterview-pro-releases
  4. Set it to PUBLIC (required for free auto-updates)
  5. Click Create repository

Step 2 - Create a GitHub Personal Access Token:
  1. Go to https://github.com/settings/tokens
  2. Click "Generate new token" > "Generate new token (classic)"
  3. Give it a name like "Better View Pro"
  4. Check the "repo" checkbox (full repo access)
  5. Click Generate token
  6. COPY THE TOKEN — you only see it once

Step 3 - Build and publish:
  In Command Prompt, in this folder, run:
    set GH_TOKEN=paste_your_token_here
    set CSC_IDENTITY_AUTO_DISCOVERY=false
    npm run build:win -- --publish always

  This builds the app AND uploads the installer to GitHub Releases automatically.

Step 4 - Install on all computers:
  Download and run the installer from:
  https://github.com/blakebvhi-op/betterview-pro-releases/releases

From now on, every time you publish a new version:
- Every installed copy of the app will detect the update on next launch
- A popup will say "Update ready - Restart Now or Later"
- One click updates the app on that computer


BUMPING THE VERSION NUMBER
---------------------------
Before each build, open package.json and change "version": "1.0.1"
to "1.0.2", "1.0.3", "1.1.0" etc.
The app uses this number to know if an update is available.


TROUBLESHOOTING
---------------

"Cannot create symbolic link" during build
  This is the most common build error. electron-builder downloads a toolchain
  package that contains Mac-format symlinks. Windows blocks symlink creation
  unless you have Administrator rights or Developer Mode enabled.

  QUICKEST FIX: Use update.bat instead of running npm directly.
  update.bat sets CSC_IDENTITY_AUTO_DISCOVERY=false which skips the symlink-
  heavy code-signing download entirely, and clears any corrupted cache first.

  If update.bat still fails, choose ONE of these fixes:

  Fix A — Enable Windows Developer Mode (recommended, one-time, no admin needed):
    1. Press Windows key, type: Developer settings
    2. Open "For developers" settings
    3. Turn on "Developer Mode"
    4. Restart Command Prompt and run update.bat again

  Fix B — Run update.bat as Administrator (works immediately):
    1. Right-click update.bat
    2. Choose "Run as administrator"
    3. The build will complete normally

  Fix C — Manually clear the corrupted cache, then re-run as admin:
    1. Delete this folder (if it exists):
       C:\Users\blake\AppData\Local\electron-builder\Cache\winCodeSign\
    2. Right-click update.bat > Run as administrator

"npm is not recognized"
  Restart Command Prompt after installing Node.js

Build fails (generic error)
  Run npm install first, then try again

App shows blank screen after installing
  Restart the app. If it persists, confirm internet is available — the app
  syncs job data with Supabase and loads weather on startup.


BUILD NOTES
-----------
- update.bat is the recommended way to build. It automatically sets the right
  environment variables and clears the cache before each build.
- The default build creates a Windows installer only (no Mac or Linux).
  Use npm run build:all if you need all platforms.
- The installer does not require Administrator rights to install.
- The app uses packaged asar output for faster load times and smaller size.

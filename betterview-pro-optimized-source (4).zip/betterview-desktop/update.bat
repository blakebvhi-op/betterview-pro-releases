@echo off
echo ================================
echo  Better View Pro - Build Update
echo ================================
echo.
cd /d "%~dp0"

rem ── Skip code-signing (prevents the winCodeSign symlink error) ──
set CSC_IDENTITY_AUTO_DISCOVERY=false
set WIN_CSC_LINK=
set WIN_CSC_KEY_PASSWORD=

rem ── Clear any corrupted winCodeSign cache entries ──────────────
set "CACHE_DIR=%LOCALAPPDATA%\electron-builder\Cache\winCodeSign"
if exist "%CACHE_DIR%" (
  echo Clearing electron-builder winCodeSign cache...
  rmdir /s /q "%CACHE_DIR%" 2>nul
)

echo Building new installer...
call npm run build:win
echo.
if errorlevel 1 (
  echo BUILD FAILED. See error above.
  echo If you see "Cannot create symbolic link", try either:
  echo   1. Right-click update.bat and choose "Run as administrator"
  echo   2. Enable Windows Developer Mode in Settings
  echo.
) else (
  echo Done! Find your installer in the dist folder.
)
echo.
pause

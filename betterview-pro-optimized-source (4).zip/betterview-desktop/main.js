const { app, BrowserWindow, Menu, shell, dialog, ipcMain } = require('electron');
const path = require('path');
const { autoUpdater } = require('electron-updater');

let mainWindow;
const isPackaged = app.isPackaged;

// ── AUTO-UPDATER ──────────────────────────────────────────────
autoUpdater.autoDownload = true;
autoUpdater.autoInstallOnAppQuit = true;

autoUpdater.on('update-available', (info) => {
  if (mainWindow) {
    const version = JSON.stringify(info.version || '');
    mainWindow.webContents.executeJavaScript(`
      (function(){
        if(document.getElementById('bv-update-bar')) return;
        const b=document.createElement('div');b.id='bv-update-bar';
        b.style.cssText='position:fixed;top:0;left:0;right:0;z-index:99999;background:#f59e0b;color:#1a1e2e;text-align:center;padding:8px 16px;font-family:sans-serif;font-size:13px;font-weight:600;';
        b.textContent='Downloading update v' + ${version} + '... will install when you close the app.';
        document.body.appendChild(b);
      })();
    `).catch(()=>{});
  }
});

autoUpdater.on('update-downloaded', (info) => {
  if (mainWindow) {
    dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: 'Update Ready — Better View Pro',
      message: `v${info.version} is ready to install`,
      detail: 'Click "Restart Now" to update, or it will install automatically next time you close the app.',
      buttons: ['Restart Now', 'Later'],
      defaultId: 0,
      cancelId: 1,
    }).then(({ response }) => {
      if (response === 0) autoUpdater.quitAndInstall(false, true);
    });
  }
});

autoUpdater.on('error', () => {});

ipcMain.on('install-update', () => {
  if (isPackaged) autoUpdater.quitAndInstall(false, true);
});

// ── WINDOW ────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 375,
    minHeight: 600,
    title: 'Better View Pro',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      devTools: !isPackaged,
    },
    backgroundColor: '#1a1e2e',
    show: false,
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isPackaged) setTimeout(() => {
      autoUpdater.checkForUpdates().catch(() => {});
    }, 3000);
  });

  mainWindow.webContents.session.setPermissionRequestHandler((_webContents, _permission, callback) => {
    callback(false);
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!url || url === 'about:blank') {
      return { action: 'allow' };
    }
    if (url.startsWith('http://') || url.startsWith('https://') || url.startsWith('mailto:')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'deny' };
  });

  mainWindow.webContents.on('will-navigate', (event, url) => {
    const currentUrl = mainWindow.webContents.getURL();
    if (url !== currentUrl) {
      event.preventDefault();
      if (url.startsWith('http://') || url.startsWith('https://') || url.startsWith('mailto:')) {
        shell.openExternal(url);
      }
    }
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

// ── MENU ──────────────────────────────────────────────────────
function buildMenu() {
  const template = [
    {
      label: 'Better View Pro',
      submenu: [
        { label: 'About Better View Pro', role: 'about' },
        { type: 'separator' },
        {
          label: 'Check for Updates…',
          click: () => {
            if (!isPackaged) {
              dialog.showMessageBox(mainWindow, {
                type: 'info',
                title: 'Updates Unavailable',
                message: 'Updates are only available in the installed app.',
                buttons: ['OK'],
              });
              return;
            }
            autoUpdater.checkForUpdates().catch(() => {
              dialog.showMessageBox(mainWindow, {
                type: 'info', title: 'Up to Date',
                message: 'You have the latest version of Better View Pro.',
                buttons: ['OK'],
              });
            });
          },
        },
        { type: 'separator' },
        { label: 'Hide', accelerator: 'CmdOrCtrl+H', role: 'hide' },
        { type: 'separator' },
        { label: 'Quit', accelerator: 'CmdOrCtrl+Q', role: 'quit' },
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { label: 'Undo', accelerator: 'CmdOrCtrl+Z', role: 'undo' },
        { label: 'Redo', accelerator: 'Shift+CmdOrCtrl+Z', role: 'redo' },
        { type: 'separator' },
        { label: 'Cut', accelerator: 'CmdOrCtrl+X', role: 'cut' },
        { label: 'Copy', accelerator: 'CmdOrCtrl+C', role: 'copy' },
        { label: 'Paste', accelerator: 'CmdOrCtrl+V', role: 'paste' },
        { label: 'Select All', accelerator: 'CmdOrCtrl+A', role: 'selectAll' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { label: 'Zoom In', accelerator: 'CmdOrCtrl+=', role: 'zoomIn' },
        { label: 'Zoom Out', accelerator: 'CmdOrCtrl+-', role: 'zoomOut' },
        { label: 'Reset Zoom', accelerator: 'CmdOrCtrl+0', role: 'resetZoom' },
        { type: 'separator' },
        { label: 'Toggle Full Screen', accelerator: 'F11', role: 'togglefullscreen' },
      ],
    },
    {
      label: 'Window',
      submenu: [
        { label: 'Minimize', accelerator: 'CmdOrCtrl+M', role: 'minimize' },
        { label: 'Close', accelerator: 'CmdOrCtrl+W', role: 'close' },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  createWindow();
  buildMenu();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

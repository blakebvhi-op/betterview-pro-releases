@echo off
echo =========================================
echo  Better View Pro - Build + Publish to GitHub
echo =========================================
echo.
cd /d "%~dp0"

rem ── You must set your GitHub token below, or set GH_TOKEN in Windows
rem    environment variables before running this script.
rem    Get a token at: https://github.com/settings/tokens
rem    Required scope: repo (or write:packages for public repos)
rem.
rem    Paste your token between the quotes on the next line:
set "GH_TOKEN="

if "%GH_TOKEN%"=="" (
  echo ERROR: GH_TOKEN is not set.
  echo.
  echo Please open this file in Notepad and paste your GitHub
  echo token between the quotes on the "set GH_TOKEN=" line,
  echo then save and run again.
  echo.
  echo You can create a token at: https://github.com/settings/tokens
  echo Make sure the token has "repo" scope selected.
  echo.
  pause
  exit /b 1
)

rem ── Skip code-signing ──────────────────────────────────────────
set CSC_IDENTITY_AUTO_DISCOVERY=false
set WIN_CSC_LINK=
set WIN_CSC_KEY_PASSWORD=

rem ── Clear winCodeSign cache ────────────────────────────────────
set "CACHE_DIR=%LOCALAPPDATA%\electron-builder\Cache\winCodeSign"
if exist "%CACHE_DIR%" (
  echo Clearing electron-builder cache...
  rmdir /s /q "%CACHE_DIR%" 2>nul
)

echo Building and publishing v%npm_package_version% to GitHub...
echo Repo: blakebvhi-op/betterview-pro-releases
echo.
call npm run build:win -- --publish always

echo.
if errorlevel 1 (
  echo PUBLISH FAILED. See error above.
  echo.
  echo Common issues:
  echo   - GH_TOKEN has wrong permissions ^(needs "repo" scope^)
  echo   - GitHub repo does not exist yet
  echo   - "Cannot create symbolic link" = enable Developer Mode or run as admin
) else (
  echo SUCCESS! New release published to GitHub.
  echo Users will be prompted to update on next app launch.
)
echo.
pause
